var searchData=
[
  ['open_5fhandshake_5ftimeout',['open_handshake_timeout',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dad2d508dc214d70b4bd6249a85987bfd6',1,'websocketpp::error']]],
  ['operation_5faborted',['operation_aborted',['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0a887436887a8732e48f7c67bd85bb6f64',1,'websocketpp::transport::error']]],
  ['operation_5fcanceled',['operation_canceled',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da3b58b6bfba3dcc3dbdf828c07bb040f4',1,'websocketpp::error']]],
  ['operation_5fnot_5fsupported',['operation_not_supported',['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0a7c3708669e1de6d4986d1db769fe214e',1,'websocketpp::transport::error']]],
  ['output_5fstream_5frequired',['output_stream_required',['../namespacewebsocketpp_1_1transport_1_1iostream_1_1error.html#a647b428e260748d7606c92255e1e9737a92341254bd27c7cb97fb5e1aca5310f3',1,'websocketpp::transport::iostream::error']]]
];
