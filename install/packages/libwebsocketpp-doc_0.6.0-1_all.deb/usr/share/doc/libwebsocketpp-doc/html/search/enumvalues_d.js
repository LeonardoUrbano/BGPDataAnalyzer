var searchData=
[
  ['reason_5frequires_5fcode',['reason_requires_code',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a2ebe84ac88fa4a93dd142d2e1ee2bbee',1,'websocketpp::processor::error']]],
  ['rejected',['rejected',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da84dc4660cd164a5e27d8c2f816f3593b',1,'websocketpp::error']]],
  ['requires_5f64bit',['requires_64bit',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a812035a236affc596d41288c8f664ee5',1,'websocketpp::processor::error']]],
  ['reserved_5fclose_5fcode',['reserved_close_code',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da58cb6e9202b34339bf0602c997de4f4c',1,'websocketpp::error::reserved_close_code()'],['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a57b405ca9c92135c21f4507722503b16',1,'websocketpp::processor::error::reserved_close_code()']]]
];
