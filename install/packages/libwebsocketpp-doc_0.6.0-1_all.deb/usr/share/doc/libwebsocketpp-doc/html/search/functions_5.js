var searchData=
[
  ['fatal_5ferror',['fatal_error',['../classwebsocketpp_1_1transport_1_1iostream_1_1connection.html#a3fdd2b1f005daafa73bffe45063a7750',1,'websocketpp::transport::iostream::connection']]]
];
