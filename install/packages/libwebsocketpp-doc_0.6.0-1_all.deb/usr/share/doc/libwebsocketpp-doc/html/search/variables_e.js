var searchData=
[
  ['rerror',['rerror',['../structwebsocketpp_1_1log_1_1elevel.html#ae8a9a9f8b1fa45a731acd340e10aa342',1,'websocketpp::log::elevel']]],
  ['rsv_5fend',['rsv_end',['../namespacewebsocketpp_1_1close_1_1status.html#a393d4a68dad55d3b3fa9d9f89d244cdf',1,'websocketpp::close::status']]],
  ['rsv_5fstart',['rsv_start',['../namespacewebsocketpp_1_1close_1_1status.html#a83200c34b3922e25125835e6a0626027',1,'websocketpp::close::status']]]
];
