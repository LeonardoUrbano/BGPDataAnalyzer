var searchData=
[
  ['uri_5fptr',['uri_ptr',['../namespacewebsocketpp.html#aae370ea5ac83a8ece7712cb39fc23f5b',1,'websocketpp']]]
];
