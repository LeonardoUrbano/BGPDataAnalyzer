var searchData=
[
  ['fail_5fhandler',['fail_handler',['../namespacewebsocketpp.html#a5bb2e61cfe649b2e012f1a2c5693a4d5',1,'websocketpp']]]
];
