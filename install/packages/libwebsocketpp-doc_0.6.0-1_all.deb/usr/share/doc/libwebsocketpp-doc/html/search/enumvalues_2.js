var searchData=
[
  ['client_5fonly',['client_only',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da34e082b99518716e9755d3ac0436ccf3',1,'websocketpp::error']]],
  ['close_5fhandshake_5ftimeout',['close_handshake_timeout',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dabd195839148da73c7dbef46688635f77',1,'websocketpp::error']]],
  ['con_5fcreation_5ffailed',['con_creation_failed',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da5e907c1c8fb01b9122f590513916c1e8',1,'websocketpp::error']]],
  ['control_5ftoo_5fbig',['control_too_big',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a10635788a8dffa63bbdfd89b2263be71',1,'websocketpp::processor::error']]]
];
