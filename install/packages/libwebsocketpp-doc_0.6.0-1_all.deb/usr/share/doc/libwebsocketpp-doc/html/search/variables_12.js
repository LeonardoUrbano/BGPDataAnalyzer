var searchData=
[
  ['warn',['warn',['../structwebsocketpp_1_1log_1_1elevel.html#aef51fd791400121297f38f4381edaebe',1,'websocketpp::log::elevel']]]
];
