var searchData=
[
  ['unsupported_5fdata',['unsupported_data',['../namespacewebsocketpp_1_1close_1_1status.html#a5c7ca7f0416a1600f92ccac7a170b442',1,'websocketpp::close::status']]],
  ['uri_5fdefault_5fport',['uri_default_port',['../namespacewebsocketpp.html#a6e6530ad7452a88796029741c5c9fab9',1,'websocketpp']]],
  ['uri_5fdefault_5fsecure_5fport',['uri_default_secure_port',['../namespacewebsocketpp.html#a57ce716bd805ddf4ef561ee7f3a5767e',1,'websocketpp']]],
  ['user_5fagent',['user_agent',['../namespacewebsocketpp.html#aa2de4611f1a9dc8d62b7dc849fae787a',1,'websocketpp']]]
];
