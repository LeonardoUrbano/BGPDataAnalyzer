var searchData=
[
  ['negotiate',['negotiate',['../classwebsocketpp_1_1extensions_1_1permessage__deflate_1_1disabled.html#a3de3aad5ffeef60e3713cc29dec7b140',1,'websocketpp::extensions::permessage_deflate::disabled::negotiate()'],['../classwebsocketpp_1_1extensions_1_1permessage__deflate_1_1enabled.html#aa05eda4f6a0231c13708445480181ff4',1,'websocketpp::extensions::permessage_deflate::enabled::negotiate()']]],
  ['negotiate_5fextensions',['negotiate_extensions',['../classwebsocketpp_1_1processor_1_1hybi13.html#a3a8e38f9640fe3b39100101af98fceee',1,'websocketpp::processor::hybi13::negotiate_extensions()'],['../classwebsocketpp_1_1processor_1_1processor.html#aad69873505ba59f4ddf53e864f32bb80',1,'websocketpp::processor::processor::negotiate_extensions()']]]
];
