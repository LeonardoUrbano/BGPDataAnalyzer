var searchData=
[
  ['patch_5fversion',['patch_version',['../namespacewebsocketpp.html#abad4a694e8698d961a16c0a3c4050d1c',1,'websocketpp']]],
  ['payload_5fsize_5fbasic',['payload_size_basic',['../namespacewebsocketpp_1_1frame_1_1limits.html#ac152368bb553f8104035ff986dee6a25',1,'websocketpp::frame::limits']]],
  ['payload_5fsize_5fextended',['payload_size_extended',['../namespacewebsocketpp_1_1frame_1_1limits.html#a99dc4f9f3be0988039217ad5dc2fd511',1,'websocketpp::frame::limits']]],
  ['payload_5fsize_5fjumbo',['payload_size_jumbo',['../namespacewebsocketpp_1_1frame_1_1limits.html#a36790aae334abd6a7f6da520588420cc',1,'websocketpp::frame::limits']]],
  ['policy_5fviolation',['policy_violation',['../namespacewebsocketpp_1_1close_1_1status.html#aa2665d76e2c1a2ce58fc5c0b5c84b884',1,'websocketpp::close::status']]],
  ['prerelease_5fflag',['prerelease_flag',['../namespacewebsocketpp.html#ae2a7cf7fd5dedc719d2921dfec4e3aa2',1,'websocketpp']]],
  ['protocol_5ferror',['protocol_error',['../namespacewebsocketpp_1_1close_1_1status.html#a4b44cedc039194173b36d510e8d88c21',1,'websocketpp::close::status']]]
];
