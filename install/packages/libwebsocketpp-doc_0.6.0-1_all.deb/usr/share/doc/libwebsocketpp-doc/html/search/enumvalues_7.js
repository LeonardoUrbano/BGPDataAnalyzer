var searchData=
[
  ['http_5fconnection_5fended',['http_connection_ended',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da378e4b84397008e32d03d0fea4f15326',1,'websocketpp::error']]],
  ['http_5fparse_5ferror',['http_parse_error',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da589164fe7382c7355310fc92ff0d53d7',1,'websocketpp::error']]]
];
