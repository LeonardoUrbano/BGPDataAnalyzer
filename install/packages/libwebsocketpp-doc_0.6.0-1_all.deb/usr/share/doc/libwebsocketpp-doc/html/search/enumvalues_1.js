var searchData=
[
  ['bad_5fclose_5fcode',['bad_close_code',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dad002d8a5b5667c6b117805b368cd7853',1,'websocketpp::error']]],
  ['bad_5fconnection',['bad_connection',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da9d05e6c7355920beb025ef1034941841',1,'websocketpp::error']]],
  ['bad_5frequest',['bad_request',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a8b5aac9eab9bc13da3a7fc1cff7d4e39',1,'websocketpp::processor::error']]],
  ['bad_5fstream',['bad_stream',['../namespacewebsocketpp_1_1transport_1_1iostream_1_1error.html#a647b428e260748d7606c92255e1e9737ad46c640654d1d96c517444d95d24da45',1,'websocketpp::transport::iostream::error']]]
];
