var searchData=
[
  ['omit_5fhandshake',['omit_handshake',['../namespacewebsocketpp_1_1close_1_1status.html#a6cfe22f9ea490b18a4fc7fc35e18569d',1,'websocketpp::close::status']]]
];
