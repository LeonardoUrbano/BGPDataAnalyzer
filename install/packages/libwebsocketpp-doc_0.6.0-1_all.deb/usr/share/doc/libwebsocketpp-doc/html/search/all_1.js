var searchData=
[
  ['bad_5fclose_5fcode',['bad_close_code',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dad002d8a5b5667c6b117805b368cd7853',1,'websocketpp::error']]],
  ['bad_5fconnection',['bad_connection',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da9d05e6c7355920beb025ef1034941841',1,'websocketpp::error']]],
  ['bad_5frequest',['bad_request',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a8b5aac9eab9bc13da3a7fc1cff7d4e39',1,'websocketpp::processor::error']]],
  ['bad_5fstream',['bad_stream',['../namespacewebsocketpp_1_1transport_1_1iostream_1_1error.html#a647b428e260748d7606c92255e1e9737ad46c640654d1d96c517444d95d24da45',1,'websocketpp::transport::iostream::error']]],
  ['base64_5fdecode',['base64_decode',['../namespacewebsocketpp.html#a1467174a88a2f4037c45dbeb9d57c481',1,'websocketpp']]],
  ['base64_5fencode',['base64_encode',['../namespacewebsocketpp.html#aff36d40583424a2c879df02219133af8',1,'websocketpp::base64_encode(unsigned char const *input, size_t len)'],['../namespacewebsocketpp.html#a3a167489f63491475d0069204edf71da',1,'websocketpp::base64_encode(std::string const &amp;input)']]],
  ['basic',['basic',['../classwebsocketpp_1_1concurrency_1_1basic.html',1,'websocketpp::concurrency']]],
  ['basic',['basic',['../classwebsocketpp_1_1log_1_1basic.html',1,'websocketpp::log']]],
  ['basic',['basic',['../classwebsocketpp_1_1log_1_1basic.html#ace381224e7990da5f3ec7505109fa541',1,'websocketpp::log::basic']]],
  ['basic_5fheader',['basic_header',['../structwebsocketpp_1_1frame_1_1basic__header.html',1,'websocketpp::frame']]],
  ['basic_5fheader_5flength',['basic_header_length',['../namespacewebsocketpp_1_1frame_1_1limits.html#aeaeca5ef49f731573507294ac019722b',1,'websocketpp::frame::limits::basic_header_length()'],['../namespacewebsocketpp_1_1frame.html#aee9c6d23ca76c30ad56757e8e2129492',1,'websocketpp::frame::BASIC_HEADER_LENGTH()']]],
  ['blank',['blank',['../namespacewebsocketpp_1_1close_1_1status.html#a6fe2aa7decc5d09b2a1a3b39cf609336',1,'websocketpp::close::status']]],
  ['body_5fready',['body_ready',['../classwebsocketpp_1_1http_1_1parser_1_1parser.html#a0ef44170d582ad2b7a99472d5269b2f8',1,'websocketpp::http::parser::parser']]],
  ['buffer',['buffer',['../structwebsocketpp_1_1transport_1_1buffer.html',1,'websocketpp::transport']]],
  ['buffered_5famount',['buffered_amount',['../classwebsocketpp_1_1connection.html#acb2fc5317ce219d92425635c1b2bde53',1,'websocketpp::connection']]],
  ['byte_5fmask',['byte_mask',['../namespacewebsocketpp_1_1frame.html#a417650d76aa2433163942d6a13334a6a',1,'websocketpp::frame::byte_mask(input_iter first, input_iter last, output_iter result, masking_key_type const &amp;key, size_t key_offset)'],['../namespacewebsocketpp_1_1frame.html#a57740a0ac6dca6789eb3d020b7f31ed8',1,'websocketpp::frame::byte_mask(iter_type b, iter_type e, masking_key_type const &amp;key, size_t key_offset)']]],
  ['byte_5fmask_5fcirc',['byte_mask_circ',['../namespacewebsocketpp_1_1frame.html#a3e0ba89b475df758d84dab352a76c3b3',1,'websocketpp::frame::byte_mask_circ(uint8_t *input, uint8_t *output, size_t length, size_t prepared_key)'],['../namespacewebsocketpp_1_1frame.html#a5e0b4f532f0d309a605e232cfdb03960',1,'websocketpp::frame::byte_mask_circ(uint8_t *data, size_t length, size_t prepared_key)']]]
];
