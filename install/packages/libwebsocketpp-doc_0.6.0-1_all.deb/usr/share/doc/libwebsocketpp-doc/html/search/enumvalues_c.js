var searchData=
[
  ['pass_5fthrough',['pass_through',['../namespacewebsocketpp_1_1transport_1_1asio_1_1error.html#aeb44b27fc0ffac2a8991bf629cbfd045a46f70de40cb49260f1d5aa454b4ecb78',1,'websocketpp::transport::asio::error::pass_through()'],['../namespacewebsocketpp_1_1transport_1_1asio_1_1socket_1_1error.html#a828ddaa5ed63a761e1b557465a35f05aaa4b14e51bb97d6ab9654ee7219ffca30',1,'websocketpp::transport::asio::socket::error::pass_through()'],['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0a6a7cb8ef776c9eabe2324a529e991732',1,'websocketpp::transport::error::pass_through()']]],
  ['payload_5fviolation',['payload_violation',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68daa2abe6fda013270792213b0f0ff8eaaf',1,'websocketpp::error']]],
  ['protocol_5fviolation',['protocol_violation',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a494d908b8b13ce4ed5f0488b1bc5c946',1,'websocketpp::processor::error']]],
  ['proxy_5ffailed',['proxy_failed',['../namespacewebsocketpp_1_1transport_1_1asio_1_1error.html#aeb44b27fc0ffac2a8991bf629cbfd045a70868b579b442f39074623c5072f86a0',1,'websocketpp::transport::asio::error']]],
  ['proxy_5finvalid',['proxy_invalid',['../namespacewebsocketpp_1_1transport_1_1asio_1_1error.html#aeb44b27fc0ffac2a8991bf629cbfd045a41380a32ff02e5e43a1ced0318c2f357',1,'websocketpp::transport::asio::error']]]
];
