var searchData=
[
  ['double_5fread',['double_read',['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0af77cb7d0fde9597a2f022a5eca0bdf61',1,'websocketpp::transport::error::double_read()'],['../namespacewebsocketpp_1_1transport_1_1iostream_1_1error.html#a647b428e260748d7606c92255e1e9737ac1ae213118c53b4d7eceb10876d88266',1,'websocketpp::transport::iostream::error::double_read()']]]
];
