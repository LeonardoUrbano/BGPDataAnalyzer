var searchData=
[
  ['request',['request',['../classwebsocketpp_1_1http_1_1parser_1_1request.html',1,'websocketpp::http::parser']]],
  ['response',['response',['../classwebsocketpp_1_1http_1_1parser_1_1response.html',1,'websocketpp::http::parser']]]
];
