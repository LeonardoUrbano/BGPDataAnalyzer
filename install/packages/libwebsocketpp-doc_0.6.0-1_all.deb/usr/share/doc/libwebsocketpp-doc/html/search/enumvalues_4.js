var searchData=
[
  ['endpoint_5fnot_5fsecure',['endpoint_not_secure',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dab60d2206b38a89602d316dd029c33c1b',1,'websocketpp::error']]],
  ['endpoint_5funavailable',['endpoint_unavailable',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da472f65367504b2e11e63682cca469be4',1,'websocketpp::error']]],
  ['eof',['eof',['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0a73dd0d0f22cd67b7bcc031cd6bdef743',1,'websocketpp::transport::error']]],
  ['extension_5fparse_5ferror',['extension_parse_error',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a595ba53f29be3b66c51ad41bd94ee29c',1,'websocketpp::processor::error']]],
  ['extensions_5fdisabled',['extensions_disabled',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a529dc9b46308d321bd52d8ced4e566e1',1,'websocketpp::processor::error']]]
];
