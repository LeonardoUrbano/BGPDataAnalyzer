var searchData=
[
  ['close_2ehpp',['close.hpp',['../close_8hpp.html',1,'']]]
];
